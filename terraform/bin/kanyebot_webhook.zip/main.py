import json

import boto3




def lambda_handler(event, context):
    # load digest from header and handle auth

        return {
            'statusCode': 200,
            'body': json.dumps('webhook_accept')
        }
